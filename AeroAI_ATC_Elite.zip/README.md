# AeroAI ATC Elite

AI-powered ATC companion app.

## Build Instructions

1. Upload to GitHub
2. Connect to Codemagic
3. Add environment variable:
   OPENAI_KEY = your_real_api_key
4. Start build
5. Download APK
